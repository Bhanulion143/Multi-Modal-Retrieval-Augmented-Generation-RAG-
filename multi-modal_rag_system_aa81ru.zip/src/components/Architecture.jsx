import React from 'react';
import { motion } from 'framer-motion';
import { Upload, FileText, Database, Search, MessageSquare, CheckCircle } from 'lucide-react';

const Architecture = () => {
  const steps = [
    {
      icon: Upload,
      title: 'Document Ingestion',
      description: 'Upload PDFs, parse text, tables, images with OCR',
      color: 'from-blue-500 to-cyan-500',
    },
    {
      icon: FileText,
      title: 'Multi-Modal Processing',
      description: 'Chunk and process different data modalities',
      color: 'from-purple-500 to-pink-500',
    },
    {
      icon: Database,
      title: 'Vector Embedding',
      description: 'Create unified embedding space for all content',
      color: 'from-green-500 to-emerald-500',
    },
    {
      icon: Search,
      title: 'Smart Retrieval',
      description: 'Semantic search across multi-modal data',
      color: 'from-orange-500 to-red-500',
    },
    {
      icon: MessageSquare,
      title: 'Answer Generation',
      description: 'Context-grounded responses with citations',
      color: 'from-indigo-500 to-blue-500',
    },
    {
      icon: CheckCircle,
      title: 'Quality Validation',
      description: 'Evaluate accuracy and faithfulness',
      color: 'from-pink-500 to-rose-500',
    },
  ];

  return (
    <section className="py-20 px-4 relative">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">
            <span className="gradient-text">System Architecture</span>
          </h2>
          <p className="text-xl text-dark-300 max-w-2xl mx-auto">
            End-to-end pipeline for multi-modal document intelligence
          </p>
        </motion.div>

        {/* Architecture Flow */}
        <div className="relative">
          {/* Connection Lines */}
          <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-primary-500 to-transparent transform -translate-y-1/2" />

          {/* Steps */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 relative z-10">
            {steps.map((step, index) => {
              const Icon = step.icon;
              
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  whileHover={{ scale: 1.05, y: -5 }}
                  className="glass-effect p-6 rounded-2xl card-hover group relative"
                >
                  {/* Step Number */}
                  <div className="absolute -top-4 -left-4 w-10 h-10 bg-gradient-to-br from-primary-500 to-primary-700 rounded-full flex items-center justify-center shadow-lg">
                    <span className="text-white font-bold">{index + 1}</span>
                  </div>

                  {/* Icon */}
                  <div className={`w-16 h-16 bg-gradient-to-br ${step.color} rounded-xl flex items-center justify-center mb-4 shadow-lg group-hover:shadow-xl transition-all duration-300 mx-auto`}>
                    <Icon className="w-8 h-8 text-white" />
                  </div>

                  {/* Content */}
                  <h3 className="text-xl font-bold text-dark-50 mb-2 text-center group-hover:text-primary-400 transition-colors duration-300">
                    {step.title}
                  </h3>
                  <p className="text-dark-400 text-sm text-center leading-relaxed">
                    {step.description}
                  </p>

                  {/* Arrow for Desktop */}
                  {index < steps.length - 1 && (
                    <div className="hidden lg:block absolute top-1/2 -right-4 transform -translate-y-1/2 z-20">
                      <motion.div
                        animate={{ x: [0, 5, 0] }}
                        transition={{ duration: 1.5, repeat: Infinity }}
                        className="w-8 h-8 bg-primary-500 rounded-full flex items-center justify-center shadow-lg"
                      >
                        <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                        </svg>
                      </motion.div>
                    </div>
                  )}
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Tech Stack */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-16"
        >
          <div className="glass-effect p-8 rounded-3xl">
            <h3 className="text-2xl font-bold text-dark-50 mb-6 text-center">
              Technology Stack
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                'React + Vite',
                'Python Backend',
                'Vector Database',
                'LLM Integration',
                'OCR Engine',
                'Embedding Models',
                'RAG Pipeline',
                'Evaluation Suite',
              ].map((tech, index) => (
                <motion.div
                  key={index}
                  whileHover={{ scale: 1.05 }}
                  className="glass-effect p-4 rounded-xl text-center"
                >
                  <span className="text-dark-200 font-medium">{tech}</span>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Architecture;
