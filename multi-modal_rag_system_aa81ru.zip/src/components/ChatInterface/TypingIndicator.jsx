import React from 'react';
import { motion } from 'framer-motion';
import { Bot } from 'lucide-react';

const TypingIndicator = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex items-start space-x-3"
    >
      <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
        <Bot className="w-5 h-5 text-white" />
      </div>
      <div className="glass-effect p-4 rounded-2xl">
        <div className="flex space-x-2 loading-dots">
          <span className="w-2 h-2 bg-primary-500 rounded-full"></span>
          <span className="w-2 h-2 bg-primary-500 rounded-full"></span>
          <span className="w-2 h-2 bg-primary-500 rounded-full"></span>
        </div>
      </div>
    </motion.div>
  );
};

export default TypingIndicator;
