import React from 'react';
import { motion } from 'framer-motion';
import { User, Bot, Copy, ThumbsUp, ThumbsDown } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import CitationList from './CitationList';

const MessageBubble = ({ message, onCopy }) => {
  return (
    <div className={`mb-6 flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
      <div className={`flex items-start space-x-3 max-w-3xl ${message.role === 'user' ? 'flex-row-reverse space-x-reverse' : ''}`}>
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${
          message.role === 'user'
            ? 'bg-gradient-to-br from-primary-500 to-primary-700'
            : 'bg-gradient-to-br from-purple-500 to-pink-500'
        }`}>
          {message.role === 'user' ? (
            <User className="w-5 h-5 text-white" />
          ) : (
            <Bot className="w-5 h-5 text-white" />
          )}
        </div>

        <div className={`flex-1 ${message.role === 'user' ? 'text-right' : ''}`}>
          <div className={`inline-block glass-effect p-4 rounded-2xl ${
            message.role === 'user' ? 'bg-primary-500/20' : ''
          }`}>
            <ReactMarkdown className="prose prose-invert prose-sm max-w-none">
              {message.content}
            </ReactMarkdown>

            {message.citations && message.citations.length > 0 && (
              <CitationList citations={message.citations} />
            )}
          </div>

          {message.role === 'assistant' && (
            <div className="flex items-center space-x-2 mt-2">
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => onCopy(message.content)}
                className="p-1.5 glass-effect rounded-lg hover:bg-white/10 transition-colors"
              >
                <Copy className="w-4 h-4 text-dark-400" />
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                className="p-1.5 glass-effect rounded-lg hover:bg-white/10 transition-colors"
              >
                <ThumbsUp className="w-4 h-4 text-dark-400" />
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                className="p-1.5 glass-effect rounded-lg hover:bg-white/10 transition-colors"
              >
                <ThumbsDown className="w-4 h-4 text-dark-400" />
              </motion.button>
            </div>
          )}

          <p className="text-xs text-dark-500 mt-1">
            {new Date(message.timestamp).toLocaleTimeString()}
          </p>
        </div>
      </div>
    </div>
  );
};

export default MessageBubble;
