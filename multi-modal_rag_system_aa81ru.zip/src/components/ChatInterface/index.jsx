import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import MessageBubble from './MessageBubble';
import TypingIndicator from './TypingIndicator';
import MessageInput from './MessageInput';

const ChatInterface = () => {
  const [messages, setMessages] = useState([
    {
      id: '1',
      role: 'assistant',
      content: "Hello! I'm your Multi-Modal RAG assistant. I can help you understand complex documents with text, tables, and images. What would you like to know?",
      timestamp: new Date().toISOString(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const mockResponses = [
    {
      content: "Based on the IMF Article IV report (Page 23, Section 4.2), the GDP growth rate for 2023 was **3.2%**, which represents a 0.5% increase from the previous year.\n\n**Key Findings:**\n- Industrial sector grew by 4.1%\n- Services sector expanded by 3.8%\n- Agricultural output increased by 2.1%\n\n**Sources:**\n- IMF_Report_2023.pdf, Page 23\n- Economic_Data_Table_Q4.pdf, Table 3",
      citations: [
        { page: 23, source: 'IMF_Report_2023.pdf', type: 'text' },
        { page: 45, source: 'Economic_Data_Table_Q4.pdf', type: 'table' },
      ],
    },
    {
      content: "The inflation trends shown in Chart 5.3 (Page 34) indicate a **declining pattern** over the past 6 months:\n\n**Monthly Breakdown:**\n- January: 5.2%\n- February: 4.8%\n- March: 4.5%\n- April: 4.2%\n- May: 3.9%\n- June: 3.7%\n\nThis represents a total decrease of **1.5 percentage points** from January to June.\n\n**Sources:**\n- Inflation_Analysis_2023.pdf, Chart 5.3, Page 34\n- Central_Bank_Report.pdf, Figure 2.1, Page 12",
      citations: [
        { page: 34, source: 'Inflation_Analysis_2023.pdf', type: 'image' },
        { page: 12, source: 'Central_Bank_Report.pdf', type: 'image' },
      ],
    },
  ];

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date().toISOString(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    await new Promise(resolve => setTimeout(resolve, 2000));

    const mockResponse = mockResponses[Math.floor(Math.random() * mockResponses.length)];
    const assistantMessage = {
      id: (Date.now() + 1).toString(),
      role: 'assistant',
      content: mockResponse.content,
      citations: mockResponse.citations,
      timestamp: new Date().toISOString(),
    };

    setMessages(prev => [...prev, assistantMessage]);
    setIsTyping(false);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
  };

  const suggestions = [
    'What is the GDP growth rate?',
    'Show me inflation trends',
    'Summarize key findings',
  ];

  return (
    <div className="min-h-screen pt-24 pb-8 px-4">
      <div className="max-w-5xl mx-auto h-[calc(100vh-12rem)] flex flex-col">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-effect p-4 rounded-2xl mb-4"
        >
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold gradient-text">Multi-Modal Chat</h1>
              <p className="text-sm text-dark-400">Ask questions about your documents</p>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-sm text-dark-300">Connected</span>
            </div>
          </div>
        </motion.div>

        <div className="flex-1 glass-effect rounded-2xl p-6 overflow-y-auto scrollbar-hide mb-4">
          <AnimatePresence>
            {messages.map((message, index) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ delay: index * 0.1 }}
              >
                <MessageBubble message={message} onCopy={copyToClipboard} />
              </motion.div>
            ))}
          </AnimatePresence>

          {isTyping && <TypingIndicator />}

          <div ref={messagesEndRef} />
        </div>

        <MessageInput
          input={input}
          onInputChange={setInput}
          onSend={handleSend}
          onKeyPress={handleKeyPress}
          isTyping={isTyping}
          suggestions={suggestions}
        />
      </div>
    </div>
  );
};

export default ChatInterface;
