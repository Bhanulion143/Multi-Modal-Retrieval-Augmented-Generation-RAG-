import React from 'react';
import { motion } from 'framer-motion';
import { FileText, Image, Table } from 'lucide-react';

const CitationList = ({ citations }) => {
  const getModalityIcon = (type) => {
    switch (type) {
      case 'text':
        return <FileText className="w-4 h-4" />;
      case 'table':
        return <Table className="w-4 h-4" />;
      case 'image':
        return <Image className="w-4 h-4" />;
      default:
        return <FileText className="w-4 h-4" />;
    }
  };

  return (
    <div className="mt-4 pt-4 border-t border-white/10">
      <p className="text-xs text-dark-400 mb-2 font-semibold">Sources:</p>
      <div className="space-y-2">
        {citations.map((citation, idx) => (
          <motion.div
            key={idx}
            whileHover={{ scale: 1.02 }}
            className="flex items-center space-x-2 text-xs glass-effect p-2 rounded-lg"
          >
            {getModalityIcon(citation.type)}
            <span className="text-dark-300">
              {citation.source}, Page {citation.page}
            </span>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default CitationList;
