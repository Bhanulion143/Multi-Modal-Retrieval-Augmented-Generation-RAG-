import React from 'react';
import { motion } from 'framer-motion';
import { Send, Loader } from 'lucide-react';

const MessageInput = ({ input, onInputChange, onSend, onKeyPress, isTyping, suggestions }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-effect p-4 rounded-2xl"
    >
      <div className="flex items-end space-x-3">
        <textarea
          value={input}
          onChange={(e) => onInputChange(e.target.value)}
          onKeyPress={onKeyPress}
          placeholder="Ask a question about your documents..."
          className="flex-1 input-field resize-none min-h-[60px] max-h-[200px]"
          rows={2}
        />
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onSend}
          disabled={!input.trim() || isTyping}
          className="btn-primary px-6 py-3 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isTyping ? (
            <Loader className="w-5 h-5 animate-spin" />
          ) : (
            <Send className="w-5 h-5" />
          )}
        </motion.button>
      </div>

      <div className="flex flex-wrap gap-2 mt-3">
        {suggestions.map((suggestion, index) => (
          <motion.button
            key={index}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onInputChange(suggestion)}
            className="text-xs glass-effect px-3 py-1.5 rounded-lg hover:bg-white/10 transition-colors text-dark-300"
          >
            {suggestion}
          </motion.button>
        ))}
      </div>
    </motion.div>
  );
};

export default MessageInput;
