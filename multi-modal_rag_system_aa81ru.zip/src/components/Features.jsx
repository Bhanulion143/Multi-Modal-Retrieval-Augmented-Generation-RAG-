import React from 'react';
import { motion } from 'framer-motion';
import { FileText, Image, Table, Search, MessageSquare, BarChart3, Zap, Shield } from 'lucide-react';

const Features = () => {
  const features = [
    {
      icon: FileText,
      title: 'Text Processing',
      description: 'Advanced NLP for semantic understanding and context extraction from complex documents',
      color: 'from-blue-500 to-cyan-500',
    },
    {
      icon: Image,
      title: 'Image OCR',
      description: 'Extract text from scanned images and charts with high accuracy using state-of-the-art OCR',
      color: 'from-purple-500 to-pink-500',
    },
    {
      icon: Table,
      title: 'Table Extraction',
      description: 'Parse and understand tabular data with structural and semantic analysis',
      color: 'from-green-500 to-emerald-500',
    },
    {
      icon: Search,
      title: 'Vector Retrieval',
      description: 'Multi-modal embedding space for unified search across all document types',
      color: 'from-orange-500 to-red-500',
    },
    {
      icon: MessageSquare,
      title: 'QA Chatbot',
      description: 'Interactive question answering with context-grounded, citation-backed responses',
      color: 'from-indigo-500 to-blue-500',
    },
    {
      icon: BarChart3,
      title: 'Evaluation Suite',
      description: 'Comprehensive benchmarking and metrics dashboard for system performance',
      color: 'from-pink-500 to-rose-500',
    },
    {
      icon: Zap,
      title: 'Fast Processing',
      description: 'Optimized pipeline with sub-2-second response times for real-time interactions',
      color: 'from-yellow-500 to-orange-500',
    },
    {
      icon: Shield,
      title: 'Source Attribution',
      description: 'Page and section-level citations for every generated answer ensuring transparency',
      color: 'from-teal-500 to-green-500',
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  return (
    <section className="py-20 px-4 relative">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">
            <span className="gradient-text">Powerful Features</span>
          </h2>
          <p className="text-xl text-dark-300 max-w-2xl mx-auto">
            Everything you need for intelligent document processing and question answering
          </p>
        </motion.div>

        {/* Features Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {features.map((feature, index) => {
            const Icon = feature.icon;
            
            return (
              <motion.div
                key={index}
                variants={itemVariants}
                whileHover={{ scale: 1.05, y: -5 }}
                className="glass-effect p-6 rounded-2xl card-hover group relative overflow-hidden"
              >
                {/* Gradient Background on Hover */}
                <div className={`absolute inset-0 bg-gradient-to-br ${feature.color} opacity-0 group-hover:opacity-10 transition-opacity duration-300`} />
                
                {/* Icon */}
                <div className={`w-14 h-14 bg-gradient-to-br ${feature.color} rounded-xl flex items-center justify-center mb-4 shadow-lg group-hover:shadow-xl transition-shadow duration-300`}>
                  <Icon className="w-7 h-7 text-white" />
                </div>

                {/* Content */}
                <h3 className="text-xl font-bold text-dark-50 mb-2 group-hover:text-primary-400 transition-colors duration-300">
                  {feature.title}
                </h3>
                <p className="text-dark-400 text-sm leading-relaxed">
                  {feature.description}
                </p>

                {/* Decorative Element */}
                <div className="absolute -bottom-2 -right-2 w-24 h-24 bg-gradient-to-br from-primary-500/10 to-transparent rounded-full blur-2xl group-hover:scale-150 transition-transform duration-500" />
              </motion.div>
            );
          })}
        </motion.div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-16 text-center"
        >
          <div className="glass-effect p-8 rounded-3xl max-w-3xl mx-auto">
            <h3 className="text-2xl font-bold text-dark-50 mb-3">
              Ready to Experience Multi-Modal Intelligence?
            </h3>
            <p className="text-dark-300 mb-6">
              Upload your documents and start asking questions with our advanced RAG system
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="btn-primary"
            >
              Get Started Now
            </motion.button>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Features;
