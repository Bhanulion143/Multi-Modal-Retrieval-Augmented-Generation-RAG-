import React from 'react';
import { motion } from 'framer-motion';
import { File, X, CheckCircle, Loader } from 'lucide-react';

const FileItem = ({ fileObj, onRemove, formatFileSize }) => {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      className="glass-effect p-4 rounded-xl"
    >
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center space-x-3 flex-1">
          <div className="w-10 h-10 bg-gradient-to-br from-primary-500 to-primary-700 rounded-lg flex items-center justify-center">
            <File className="w-5 h-5 text-white" />
          </div>
          
          <div className="flex-1 min-w-0">
            <p className="text-dark-50 font-medium truncate">
              {fileObj.name}
            </p>
            <p className="text-sm text-dark-400">
              {formatFileSize(fileObj.size)}
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          {fileObj.status === 'completed' && (
            <CheckCircle className="w-5 h-5 text-green-500" />
          )}
          {fileObj.status === 'processing' && (
            <Loader className="w-5 h-5 text-primary-500 animate-spin" />
          )}
          <button
            onClick={() => onRemove(fileObj.id)}
            className="p-1 hover:bg-red-500/20 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-red-500" />
          </button>
        </div>
      </div>

      {fileObj.status === 'processing' && (
        <div className="relative h-2 bg-dark-700 rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${fileObj.progress}%` }}
            className="absolute inset-y-0 left-0 bg-gradient-to-r from-primary-500 to-primary-600"
          />
        </div>
      )}
    </motion.div>
  );
};

export default FileItem;
