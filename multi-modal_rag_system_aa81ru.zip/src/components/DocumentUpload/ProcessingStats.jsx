import React from 'react';
import { motion } from 'framer-motion';
import { FileText, Table, Image } from 'lucide-react';

const ProcessingStats = ({ uploadedFiles }) => {
  const stats = [
    { 
      icon: FileText, 
      label: 'Text Chunks', 
      value: uploadedFiles.reduce((acc, f) => acc + (f.status === 'completed' ? Math.floor(Math.random() * 30) + 10 : 0), 0) 
    },
    { 
      icon: Table, 
      label: 'Tables Found', 
      value: uploadedFiles.reduce((acc, f) => acc + (f.status === 'completed' ? Math.floor(Math.random() * 5) + 1 : 0), 0) 
    },
    { 
      icon: Image, 
      label: 'Images Processed', 
      value: uploadedFiles.reduce((acc, f) => acc + (f.status === 'completed' ? Math.floor(Math.random() * 8) + 2 : 0), 0) 
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="grid grid-cols-3 gap-4 mt-8"
    >
      {stats.map((stat, index) => {
        const Icon = stat.icon;
        return (
          <div key={index} className="glass-effect p-4 rounded-xl text-center">
            <Icon className="w-6 h-6 text-primary-400 mx-auto mb-2" />
            <div className="text-2xl font-bold gradient-text">{stat.value}</div>
            <div className="text-sm text-dark-400">{stat.label}</div>
          </div>
        );
      })}
    </motion.div>
  );
};

export default ProcessingStats;
