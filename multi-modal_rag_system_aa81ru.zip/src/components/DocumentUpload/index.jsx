import React, { useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { useDropzone } from 'react-dropzone';
import { useDocumentStore } from '../../stores/documentStore';
import UploadArea from './UploadArea';
import ProcessingStats from './ProcessingStats';
import FileList from './FileList';

const DocumentUpload = () => {
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [processing, setProcessing] = useState(false);
  const { addDocument } = useDocumentStore();

  const onDrop = useCallback((acceptedFiles) => {
    const newFiles = acceptedFiles.map(file => ({
      id: Math.random().toString(36).substr(2, 9),
      file,
      name: file.name,
      size: file.size,
      status: 'pending',
      progress: 0,
    }));
    
    setUploadedFiles(prev => [...prev, ...newFiles]);
    processFiles(newFiles);
  }, []);

  const processFiles = async (files) => {
    setProcessing(true);
    
    for (const fileObj of files) {
      for (let i = 0; i <= 100; i += 10) {
        await new Promise(resolve => setTimeout(resolve, 200));
        setUploadedFiles(prev =>
          prev.map(f =>
            f.id === fileObj.id
              ? { ...f, progress: i, status: i === 100 ? 'completed' : 'processing' }
              : f
          )
        );
      }
      
      addDocument({
        id: fileObj.id,
        name: fileObj.name,
        size: fileObj.size,
        uploadedAt: new Date().toISOString(),
        modalities: ['text', 'tables', 'images'],
        chunks: Math.floor(Math.random() * 50) + 20,
      });
    }
    
    setProcessing(false);
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'image/*': ['.png', '.jpg', '.jpeg'],
    },
  });

  const removeFile = (id) => {
    setUploadedFiles(prev => prev.filter(f => f.id !== id));
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
  };

  return (
    <div className="min-h-screen pt-32 pb-20 px-4">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">
            <span className="gradient-text">Upload Documents</span>
          </h1>
          <p className="text-xl text-dark-300">
            Upload PDFs or images to start processing with our multi-modal RAG system
          </p>
        </motion.div>

        <UploadArea
          getRootProps={getRootProps}
          getInputProps={getInputProps}
          isDragActive={isDragActive}
        />

        {uploadedFiles.length > 0 && (
          <ProcessingStats uploadedFiles={uploadedFiles} />
        )}

        <FileList
          uploadedFiles={uploadedFiles}
          onRemoveFile={removeFile}
          formatFileSize={formatFileSize}
        />

        {uploadedFiles.some(f => f.status === 'completed') && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-8 flex justify-center space-x-4"
          >
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => window.location.href = '/chat'}
              className="btn-primary"
            >
              Start Asking Questions
            </motion.button>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default DocumentUpload;
