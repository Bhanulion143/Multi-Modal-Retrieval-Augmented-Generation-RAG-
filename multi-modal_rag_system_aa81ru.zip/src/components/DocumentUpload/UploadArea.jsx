import React from 'react';
import { motion } from 'framer-motion';
import { Upload } from 'lucide-react';

const UploadArea = ({ getRootProps, getInputProps, isDragActive }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 }}
      {...getRootProps()}
      className={`glass-effect border-2 border-dashed rounded-3xl p-12 text-center cursor-pointer transition-all duration-300 ${
        isDragActive
          ? 'border-primary-500 bg-primary-500/10'
          : 'border-dark-600 hover:border-primary-500/50 hover:bg-white/5'
      }`}
    >
      <input {...getInputProps()} />
      
      <motion.div
        animate={{
          scale: isDragActive ? 1.1 : 1,
          rotate: isDragActive ? 5 : 0,
        }}
        transition={{ duration: 0.3 }}
        className="w-20 h-20 bg-gradient-to-br from-primary-500 to-primary-700 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg"
      >
        <Upload className="w-10 h-10 text-white" />
      </motion.div>

      <h3 className="text-2xl font-bold text-dark-50 mb-2">
        {isDragActive ? 'Drop files here' : 'Drag & drop files'}
      </h3>
      <p className="text-dark-400 mb-4">
        or click to browse from your computer
      </p>
      <p className="text-sm text-dark-500">
        Supports PDF, PNG, JPG • Max 50MB per file
      </p>
    </motion.div>
  );
};

export default UploadArea;
