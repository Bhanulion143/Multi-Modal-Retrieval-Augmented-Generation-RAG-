import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import FileItem from './FileItem';

const FileList = ({ uploadedFiles, onRemoveFile, formatFileSize }) => {
  if (uploadedFiles.length === 0) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        className="mt-8 space-y-4"
      >
        <h3 className="text-xl font-bold text-dark-50 mb-4">
          Uploaded Files ({uploadedFiles.length})
        </h3>
        
        {uploadedFiles.map((fileObj) => (
          <FileItem
            key={fileObj.id}
            fileObj={fileObj}
            onRemove={onRemoveFile}
            formatFileSize={formatFileSize}
          />
        ))}
      </motion.div>
    </AnimatePresence>
  );
};

export default FileList;
