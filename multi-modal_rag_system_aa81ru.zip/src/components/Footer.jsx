import React from 'react';
import { motion } from 'framer-motion';
import { Github, Linkedin, Twitter, Mail, FileText } from 'lucide-react';

const Footer = () => {
  const socialLinks = [
    { icon: Github, href: '#', label: 'GitHub' },
    { icon: Linkedin, href: '#', label: 'LinkedIn' },
    { icon: Twitter, href: '#', label: 'Twitter' },
    { icon: Mail, href: '#', label: 'Email' },
  ];

  return (
    <footer className="glass-effect border-t border-white/10 mt-20">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* Brand */}
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-primary-500 to-primary-700 rounded-xl flex items-center justify-center">
                <FileText className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold gradient-text">MultiModal RAG</span>
            </div>
            <p className="text-dark-400 text-sm leading-relaxed">
              Advanced Multi-Modal Retrieval-Augmented Generation system for intelligent document processing and question answering.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold text-dark-50 mb-4">Quick Links</h3>
            <ul className="space-y-2">
              {['Documentation', 'API Reference', 'GitHub Repository', 'Technical Report'].map((link, index) => (
                <li key={index}>
                  <a
                    href="#"
                    className="text-dark-400 hover:text-primary-400 transition-colors text-sm"
                  >
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Connect */}
          <div>
            <h3 className="text-lg font-bold text-dark-50 mb-4">Connect</h3>
            <div className="flex space-x-3">
              {socialLinks.map((social, index) => {
                const Icon = social.icon;
                return (
                  <motion.a
                    key={index}
                    href={social.href}
                    whileHover={{ scale: 1.1, y: -2 }}
                    whileTap={{ scale: 0.9 }}
                    className="w-10 h-10 glass-effect rounded-xl flex items-center justify-center hover:bg-primary-500/20 transition-colors"
                    aria-label={social.label}
                  >
                    <Icon className="w-5 h-5 text-dark-400" />
                  </motion.a>
                );
              })}
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between">
          <p className="text-dark-500 text-sm mb-4 md:mb-0">
            © 2024 MultiModal RAG System. Built for the LLM Challenge.
          </p>
          <div className="flex space-x-6 text-sm">
            <a href="#" className="text-dark-400 hover:text-primary-400 transition-colors">
              Privacy Policy
            </a>
            <a href="#" className="text-dark-400 hover:text-primary-400 transition-colors">
              Terms of Service
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
