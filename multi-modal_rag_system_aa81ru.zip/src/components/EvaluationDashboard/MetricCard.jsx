import React from 'react';
import { motion } from 'framer-motion';

const MetricCard = ({ metric, index }) => {
  const Icon = metric.icon;
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      whileHover={{ scale: 1.05, y: -5 }}
      className="glass-effect p-6 rounded-2xl card-hover"
    >
      <div className="flex items-center justify-between mb-4">
        <div className={`w-12 h-12 bg-gradient-to-br ${metric.color} rounded-xl flex items-center justify-center shadow-lg`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
        <span className={`text-sm font-semibold ${
          metric.change.startsWith('+') ? 'text-green-500' : 'text-red-500'
        }`}>
          {metric.change}
        </span>
      </div>
      <h3 className="text-dark-400 text-sm mb-1">{metric.name}</h3>
      <p className="text-3xl font-bold gradient-text">
        {metric.value}{metric.unit || '%'}
      </p>
    </motion.div>
  );
};

export default MetricCard;
