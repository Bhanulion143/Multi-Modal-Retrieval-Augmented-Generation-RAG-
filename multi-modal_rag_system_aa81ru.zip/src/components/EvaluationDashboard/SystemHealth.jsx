import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle } from 'lucide-react';

const SystemHealth = ({ healthData }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.6 }}
      className="glass-effect p-6 rounded-2xl"
    >
      <h3 className="text-xl font-bold text-dark-50 mb-6">System Health</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {healthData.map((item, index) => (
          <div key={index} className="text-center">
            <div className={`inline-flex items-center justify-center w-16 h-16 rounded-full mb-3 ${
              item.status === 'excellent'
                ? 'bg-green-500/20'
                : 'bg-yellow-500/20'
            }`}>
              <CheckCircle className={`w-8 h-8 ${
                item.status === 'excellent'
                  ? 'text-green-500'
                  : 'text-yellow-500'
              }`} />
            </div>
            <p className="text-2xl font-bold gradient-text mb-1">{item.value}</p>
            <p className="text-sm text-dark-400">{item.label}</p>
          </div>
        ))}
      </div>
    </motion.div>
  );
};

export default SystemHealth;
