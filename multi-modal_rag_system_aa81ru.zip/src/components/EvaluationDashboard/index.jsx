import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, Target, Zap, CheckCircle } from 'lucide-react';
import MetricCard from './MetricCard';
import PerformanceChart from './PerformanceChart';
import ResponseTimeChart from './ResponseTimeChart';
import ModalityPieChart from './ModalityPieChart';
import BenchmarkQueries from './BenchmarkQueries';
import SystemHealth from './SystemHealth';

const EvaluationDashboard = () => {
  const metrics = [
    { name: 'Accuracy', value: 95, icon: Target, color: 'from-green-500 to-emerald-500', change: '+2.3%' },
    { name: 'Faithfulness', value: 92, icon: CheckCircle, color: 'from-blue-500 to-cyan-500', change: '+1.8%' },
    { name: 'Response Time', value: 1.8, icon: Zap, color: 'from-yellow-500 to-orange-500', change: '-0.2s', unit: 's' },
    { name: 'Coverage', value: 88, icon: TrendingUp, color: 'from-purple-500 to-pink-500', change: '+3.1%' },
  ];

  const performanceData = [
    { name: 'Text', accuracy: 96, faithfulness: 94, coverage: 92 },
    { name: 'Tables', accuracy: 93, faithfulness: 91, coverage: 87 },
    { name: 'Images', accuracy: 89, faithfulness: 88, coverage: 85 },
    { name: 'Mixed', accuracy: 95, faithfulness: 93, coverage: 90 },
  ];

  const responseTimeData = [
    { time: '0-1s', count: 45 },
    { time: '1-2s', count: 35 },
    { time: '2-3s', count: 15 },
    { time: '3-4s', count: 5 },
  ];

  const modalityDistribution = [
    { name: 'Text', value: 45, color: '#3b82f6' },
    { name: 'Tables', value: 25, color: '#8b5cf6' },
    { name: 'Images', value: 20, color: '#ec4899' },
    { name: 'Mixed', value: 10, color: '#f59e0b' },
  ];

  const benchmarkQueries = [
    {
      query: 'What is the GDP growth rate for 2023?',
      modality: 'Text + Table',
      accuracy: 98,
      responseTime: 1.2,
      status: 'success',
    },
    {
      query: 'Analyze the inflation trend chart',
      modality: 'Image + Text',
      accuracy: 94,
      responseTime: 1.8,
      status: 'success',
    },
    {
      query: 'Compare quarterly revenue figures',
      modality: 'Table',
      accuracy: 96,
      responseTime: 1.5,
      status: 'success',
    },
    {
      query: 'Summarize policy recommendations',
      modality: 'Text',
      accuracy: 92,
      responseTime: 2.1,
      status: 'warning',
    },
  ];

  const healthData = [
    { label: 'Uptime', value: '99.9%', status: 'excellent' },
    { label: 'Avg. Latency', value: '1.8s', status: 'good' },
    { label: 'Error Rate', value: '0.2%', status: 'excellent' },
  ];

  return (
    <div className="min-h-screen pt-32 pb-20 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">
            <span className="gradient-text">Evaluation Dashboard</span>
          </h1>
          <p className="text-xl text-dark-300">
            Comprehensive metrics and benchmarks for system performance
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {metrics.map((metric, index) => (
            <MetricCard key={index} metric={metric} index={index} />
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <PerformanceChart data={performanceData} />
          <ResponseTimeChart data={responseTimeData} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <ModalityPieChart data={modalityDistribution} />
          <BenchmarkQueries queries={benchmarkQueries} />
        </div>

        <SystemHealth healthData={healthData} />
      </div>
    </div>
  );
};

export default EvaluationDashboard;
