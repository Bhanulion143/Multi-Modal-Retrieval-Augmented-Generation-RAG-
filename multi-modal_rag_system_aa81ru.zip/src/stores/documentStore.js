import { create } from 'zustand';

export const useDocumentStore = create((set) => ({
  documents: [],
  
  addDocument: (document) =>
    set((state) => ({
      documents: [...state.documents, document],
    })),
  
  removeDocument: (id) =>
    set((state) => ({
      documents: state.documents.filter((doc) => doc.id !== id),
    })),
  
  clearDocuments: () =>
    set({ documents: [] }),
}));
